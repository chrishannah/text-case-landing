# Text Case 2026.1 brings reusable text edits to the Mac menu bar

Text Case 2026.1 is available for iPhone, iPad and Mac. The update makes it easier to turn a series of text edits into a saved flow. A new Mac menu bar picker runs flows and formats on the clipboard from anywhere.

The update includes five ready-to-try templates. You can paste your own example, see the result and copy it without saving a flow. The updated builder shows what each step does. A list cleanup flow, for example, can remove extra spaces, blank lines and duplicates before sorting what’s left.

The redesigned Scratchpad makes it easier to find and compare formats. Users can also save an instruction as an AI format on supported devices with Apple Intelligence available. AI generation runs on the device and results can be reviewed before use.

Text Case requires iOS or iPadOS 26.0 or later, or macOS 26.0 or later. See the [iPhone and iPad listing](https://apps.apple.com/app/id1407730596) and the [Mac listing](https://apps.apple.com/app/id1492174677) for local pricing and availability.

[Text Case website](https://textcase.app/) · [Press contact](https://chrishannah.me/contact/) · [Starter flows](Flows/README.md)
