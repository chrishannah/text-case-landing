# Starter flows for Text Case 2026.1

Download a `.textcaseflow` file and open it from Files or Finder. Choose **Import** in Text Case, or drag the file onto the Flows list. Then open your editable copy and preview it using one of the samples below.

## Clean and Sort a List

[Download the flow](clean-and-sort-a-list.textcaseflow)

Try this on a list copied from an email or note. The flow normalises line endings, trims each line, removes blank lines and exact duplicates, then sorts the result. It treats differently capitalised lines as distinct.

Input:

```text
Pears

  Apples
Pears
Bananas
```

Output:

```text
Apples
Bananas
Pears
```

## Make a URL Slug

[Download the flow](make-a-url-slug.textcaseflow)

This turns a heading split across lines into a lowercase URL path segment. For example, “A better way” followed by “to work with text!” becomes `a-better-way-to-work-with-text`. The same recipe is also available under Templates.

## US to British English

[Download the flow](us-to-british-english.textcaseflow)

Try “We analyzed the color options and organized the files by our favorite neighborhood.” A possible result is “We analysed the colour options and organised the files by our favourite neighbourhood.”

This recipe contains an AI step. Open it in the Text Case main app on a supported device with Apple Intelligence available and run the preview. Check the wording before you copy the result. Update the Text Case apps on other devices before putting AI flows in a shared iCloud collection. The prompt is part of the flow, so you can inspect and edit it.
