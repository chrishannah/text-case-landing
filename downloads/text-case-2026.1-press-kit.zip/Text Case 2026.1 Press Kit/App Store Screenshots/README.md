# Text Case 2026.1 App Store screenshots

The numbered folders map to the display slots in App Store Connect. Upload the PNGs in filename order. The contact sheet is for review only. All artwork is in English and uses real Text Case UI with sample text.

| Folder | Dimensions | Images |
| --- | --- | --- |
| iPhone with Dynamic Island, medium | 1206 × 2622 | Scratchpad, flow template, flow builder, reusable AI prompt |
| iPhone with Dynamic Island, large | 1320 × 2868 | Scratchpad, flow template, flow builder, reusable AI prompt |
| 13-inch iPad | 2752 × 2064 | Scratchpad, flow template, flow builder |
| iPhone Duo, outer | 1398 × 2034 | Scratchpad, folded |
| iPhone Duo, inner | 2853 × 2007 | Scratchpad, unfolded |
| Mac | 2560 × 1600 | Menu bar picker, flow builder, Scratchpad, AI Transform |

The medium iPhone, 13-inch iPad, and Mac folders cover Apple's listed required displays for Text Case. The large iPhone and Duo folders provide artwork for those display slots. Apple can scale the main artwork for smaller displays.

## Capture sources

- The large iPhone Scratchpad is a native capture from a build 136-based simulator app. The remaining iPhone and iPad panels use build 136 UIKit test renders. The reusable AI screenshot shows the actual prompt editor.
- The Mac images use earlier live development captures, including an actual AI Transform result. The Duo images use earlier Device Hub captures of the two postures and include the device frame. Compare the Mac and Duo artwork with the final release candidate before submission.
- The PNGs are opaque RGB at the dimensions above. Files have not been submitted to App Store Connect.

[Apple screenshot specifications](https://developer.apple.com/help/app-store-connect/reference/app-information/screenshot-specifications/)
