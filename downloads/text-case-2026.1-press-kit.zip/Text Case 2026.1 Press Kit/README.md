# Text Case 2026.1 press kit

Text Case is an independent text formatting app for iPhone, iPad and Mac. It turns a series of text edits into a flow you can run again. Clean up a list, prepare a headline, format JSON, or give a routine transformation a place in the Mac menu bar.

[Release announcement](Announcement.md)

## In this release

- **Scratchpad** lets you compare outputs, find favourites, see the full result, and copy it or use it as input for another edit.
- **Five flow templates** offer editable examples for lists, pasted text, headlines, URL slugs and Markdown quotes.
- **The flow builder** shows the result at every step. You can switch steps off as you experiment and keep their settings.
- **The Mac menu bar picker** searches flows and formats, runs a transformation on copied text and provides one-level clipboard recovery.
- **AI formats** save an instruction as a reusable step. Generation happens on the device when Apple Intelligence is available. AI flows run in the main app.

## Try it in a minute

Open **Flows → Templates → Clean a List**. The example includes a blank line and a duplicate. Try replacing the example with a list of your own, then copy the result or save an editable flow. On Mac, try running it against a fresh copy of the same text from the menu bar. For more recipes, see [Starter Flows](Flows/README.md).

## Product facts

| | |
| --- | --- |
| Version | 2026.1 |
| Developer | Chris Hannah, independent developer |
| Requirements | iOS/iPadOS 26.0 or later, or macOS 26.0 or later |
| AI requirements | Supported device with Apple Intelligence enabled and the system model available |
| Pricing and availability | See the separate App Store listings for local pricing and availability |
| Website | [textcase.app](https://textcase.app/) |
| Download | [iPhone and iPad](https://apps.apple.com/app/id1407730596) · [Mac](https://apps.apple.com/app/id1492174677) |
| Press contact | [Chris Hannah](https://chrishannah.me/contact/) |

The press ZIP includes 17 full-resolution screenshots, icons for iOS and Mac, App Store header and search artwork, a social preview image, and downloadable flow examples. The screenshot folder includes a contact sheet, dimensions, and capture notes. All screenshots use synthetic sample text.
