# Text Case 2026.1 App Store screenshots

Upload the opaque PNGs in filename order, using the corresponding display slot. The images use sample text and the app's real UIKit screens.

[Apple screenshot specifications](https://developer.apple.com/help/app-store-connect/reference/app-information/screenshot-specifications/)

| Slot | Dimensions | Capture status |
| --- | --- | --- |
| Mac | 2560 × 1600 | Three build 138 app-view renders |
| iPhone with Dynamic Island, large | 1320 × 2868 | Three build 138 app-view renders |
| iPhone with Dynamic Island, medium | 1206 × 2622 | Three build 138 app-view renders |
| 13-inch iPad | 2752 × 2064 | One build 138 template render at iPad dimensions |
| iPhone Duo, outer | 1398 × 2034 | One build 138 app-view render |
| iPhone Duo, inner | 2853 × 2007 | Pending a live unfolded capture |
