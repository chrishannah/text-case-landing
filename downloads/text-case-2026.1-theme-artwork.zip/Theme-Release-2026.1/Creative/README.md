# App Store creative artwork

Each palette folder contains three opaque sRGB PNGs. Use **Signature** as the default artwork for the release. Plum, Ember and Woodland are alternative treatments.

| File | Placement | Dimensions |
| --- | --- | --- |
| product-page-header.png | Product page header | 3840 × 1646 |
| search-results.png | Search results | 3840 × 2560 |
| universal.png | Universal asset | 5244 × 2950 |

The artwork uses the shipped Aa icon from the corresponding palette. The mark sits within Apple's art safe area for its placement. Use the product page header and search results pair if assigning artwork per placement, or the universal file if assigning one asset to both. Preview the storefront crops in App Store Connect before submission.

[Apple creative asset specifications](https://developer.apple.com/help/app-store-connect/reference/app-information/creative-assets-specifications)
