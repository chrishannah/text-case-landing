# Text Case 2026.1 theme release artwork

| Folder | Contents |
| --- | --- |
| App-Store | Build 138 App Store PNGs for Mac, both standard iPhone sizes, 13-inch iPad and the Duo outer display. See the slot checklist. |
| Website | Eight 1600 × 1135 WebP screenshots of the same Scratchpad view across Signature, Plum, Ember and Woodland in light and dark. Open index.html to review. |
| Creative | Twelve opaque PNGs covering product page header, search results and universal artwork for all four palettes. Signature is the proposed default. |

The screenshots were rendered from the real app views with synthetic input in an Xcode test host. The Mac set covers Scratchpad, the Clean a List template and the flow builder. Live Mac window chrome and menu bar picker are pending. The capture test passed. Separate adaptive layout and theme assertions in the wider suite failed on Mac Catalyst, so the capture run does not sign off the full app.

The mobile capture test passed on the iPhone Duo simulator. It rendered the app's views at the two standard iPhone sizes, the 13-inch iPad size and the Duo outer size. The standard iPhone and iPad images are layout renders from this test host. The Duo inner render was withheld because its controls overlapped the content. See the App Store slot checklist for the iPad status.

Artwork dimensions and RGB output were checked locally. Storefront crop previews and asset acceptance remain to be checked in App Store Connect.
